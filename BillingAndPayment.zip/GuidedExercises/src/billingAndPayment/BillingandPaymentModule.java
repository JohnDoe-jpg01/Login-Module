package billingAndPayment;

import java.awt.EventQueue;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.text.*;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.ZoneId;

public class BillingandPaymentModule extends JFrame {

	private static final long serialVersionUID = 1L;

	// Main container panel for all components
	private JPanel contentPane;

	// Labels to display patient info (non-editable)
	private JLabel lblNameValue, lblIDValue, lblAddressValue, lblPhoneValue;

	// Input fields for fees, discount, and card number
	private JTextField tfProfFee, tfAmount, tfDiscount, tfCardNumber;

	// Text area to display generated bill summary
	private JTextArea textArea;

	// Combo boxes for lab test and payment mode selection
	private JComboBox<String> cbLabTest, cbPaymentMode;

	// Label for Card Number input (visible only when payment mode requires it)
	private JLabel lblCardNumber;

	// Label to display any error messages to user
	private JLabel lblErrorMessage;

	// Simulated patient data (could be replaced with real patient info)
	private String patientName = "Juan Dela Cruz";
	private String patientID = "P123456";
	private String patientAddress = "1234 Mabini St., Manila";
	private String patientPhone = "09171234567";

	/**
	 * Main method - Entry point for the application. Launches the GUI on the Event
	 * Dispatch Thread.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {
			try {
				BillingandPaymentModule frame = new BillingandPaymentModule();
				frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

	/**
	 * Constructor: Builds the GUI, initializes components, and sets up event
	 * handlers.
	 */
	public BillingandPaymentModule() {
		// Setup JFrame properties
		setTitle("OsMak | Billing and Payment");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 780, 600);

		// Initialize main content panel with background and padding
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 250, 250)); // off-white background
		contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
		setContentPane(contentPane);
		contentPane.setLayout(null); // absolute positioning

		// --- Title Label ---
		JLabel lblTitle = new JLabel("OsMak.");
		lblTitle.setForeground(new Color(65, 65, 65));
		lblTitle.setFont(new Font("HelveticaNowDisplay ExtraBold", Font.BOLD, 22));
		lblTitle.setBounds(20, 20, 100, 30);
		contentPane.add(lblTitle);

		// --- Patient Information Section ---
		JLabel lblPatientInfo = new JLabel("Patient Information");
		lblPatientInfo.setFont(new Font("HelveticaNowDisplay Medium", Font.PLAIN, 16));
		lblPatientInfo.setBounds(20, 70, 200, 25);
		contentPane.add(lblPatientInfo);

		// Patient Name Label + Value (non-editable)
		JLabel lblName = new JLabel("Full Name:");
		lblName.setBounds(20, 100, 100, 20);
		contentPane.add(lblName);
		lblNameValue = new JLabel(patientName);
		lblNameValue.setBounds(130, 100, 200, 20);
		contentPane.add(lblNameValue);

		// Patient ID Label + Value
		JLabel lblID = new JLabel("Patient ID:");
		lblID.setBounds(20, 130, 100, 20);
		contentPane.add(lblID);
		lblIDValue = new JLabel(patientID);
		lblIDValue.setBounds(130, 130, 200, 20);
		contentPane.add(lblIDValue);

		// Address Label + Value
		JLabel lblAddress = new JLabel("Address:");
		lblAddress.setBounds(20, 160, 100, 20);
		contentPane.add(lblAddress);
		lblAddressValue = new JLabel(patientAddress);
		lblAddressValue.setBounds(130, 160, 200, 20);
		contentPane.add(lblAddressValue);

		// Phone Number Label + Value
		JLabel lblPhone = new JLabel("Phone Number:");
		lblPhone.setBounds(20, 190, 100, 20);
		contentPane.add(lblPhone);
		lblPhoneValue = new JLabel(patientPhone);
		lblPhoneValue.setBounds(130, 190, 200, 20);
		contentPane.add(lblPhoneValue);

		// NOTE: Date label removed from UI as requested.

		// --- Hospital Charges Section ---
		JLabel lblCharges = new JLabel("Hospital Charges");
		lblCharges.setFont(new Font("HelveticaNowDisplay Medium", Font.PLAIN, 16));
		lblCharges.setBounds(400, 70, 200, 25);
		contentPane.add(lblCharges);

		// Professional Fee input field
		JLabel lblProfFee = new JLabel("Professional Fee:");
		lblProfFee.setBounds(400, 100, 120, 20);
		contentPane.add(lblProfFee);
		tfProfFee = new JTextField();
		tfProfFee.setBounds(530, 100, 180, 20);
		contentPane.add(tfProfFee);

		// Lab Test selection combobox
		JLabel lblLabTest = new JLabel("Lab Test:");
		lblLabTest.setBounds(400, 130, 120, 20);
		contentPane.add(lblLabTest);
		cbLabTest = new JComboBox<>(new String[] { "Blood Test", "Urinalysis", "X-ray", "MRI", "ECG" });
		cbLabTest.setBounds(530, 130, 180, 20);
		contentPane.add(cbLabTest);

		// Test Amount input field
		JLabel lblAmount = new JLabel("Test Amount:");
		lblAmount.setBounds(400, 160, 120, 20);
		contentPane.add(lblAmount);
		tfAmount = new JTextField();
		tfAmount.setBounds(530, 160, 180, 20);
		contentPane.add(tfAmount);

		// Discount input field
		JLabel lblDiscount = new JLabel("Discount:");
		lblDiscount.setBounds(400, 190, 120, 20);
		contentPane.add(lblDiscount);
		tfDiscount = new JTextField();
		tfDiscount.setBounds(530, 190, 180, 20);
		contentPane.add(tfDiscount);

		// Mode of Payment combobox
		JLabel lblPaymentMode = new JLabel("Mode of Payment:");
		lblPaymentMode.setBounds(400, 220, 120, 20);
		contentPane.add(lblPaymentMode);
		cbPaymentMode = new JComboBox<>(new String[] { "Cash", "Debit", "Credit" });
		cbPaymentMode.setBounds(530, 220, 180, 20);
		contentPane.add(cbPaymentMode);

		// Card Number label and input field (only visible if Debit or Credit is
		// selected)
		lblCardNumber = new JLabel("Card Number:");
		lblCardNumber.setBounds(400, 250, 120, 20);
		lblCardNumber.setVisible(false);
		contentPane.add(lblCardNumber);

		tfCardNumber = new JTextField();
		tfCardNumber.setBounds(530, 250, 180, 20);
		tfCardNumber.setVisible(false);
		// Limit input to numeric digits and max length 16 for card number
		((AbstractDocument) tfCardNumber.getDocument()).setDocumentFilter(new DocumentFilter() {
			public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr)
					throws BadLocationException {
				if (string == null)
					return;
				if ((fb.getDocument().getLength() + string.length()) <= 16 && string.matches("[0-9]+")) {
					super.insertString(fb, offset, string, attr);
				}
			}

			public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
					throws BadLocationException {
				if (text == null)
					return;
				if ((fb.getDocument().getLength() - length + text.length()) <= 16 && text.matches("[0-9]+")) {
					super.replace(fb, offset, length, text, attrs);
				}
			}
		});
		contentPane.add(tfCardNumber);

		// --- Buttons ---
		JButton btnGenerate = new JButton("Generate Bill");
		btnGenerate.setBounds(20, 290, 140, 25);
		contentPane.add(btnGenerate);

		JButton btnClear = new JButton("Clear");
		btnClear.setBounds(170, 290, 140, 25);
		contentPane.add(btnClear);

		// --- TextArea for displaying the generated bill ---
		textArea = new JTextArea();
		textArea.setEditable(false);
		textArea.setBounds(20, 330, 720, 180); // starting height, will adjust dynamically
		textArea.setFont(new Font("Monospaced", Font.PLAIN, 12)); // monospace for alignment
		contentPane.add(textArea);

		// --- Label for eConsult branding ---
		JLabel lblEconsult = new JLabel("eConsult");
		lblEconsult.setForeground(new Color(0, 128, 255));
		lblEconsult.setFont(new Font("HelveticaNowDisplay ExtraBold", Font.BOLD, 22));
		lblEconsult.setBounds(109, 20, 100, 30);
		contentPane.add(lblEconsult);

		// Label to show validation and error messages in red
		lblErrorMessage = new JLabel("");
		lblErrorMessage.setForeground(Color.RED);
		lblErrorMessage.setBounds(20, 560, 720, 20);
		contentPane.add(lblErrorMessage);

		/**
		 * Event Listener: Show or hide Card Number input based on selected payment
		 * mode. If payment mode is Debit or Credit, card input field appears.
		 */
		cbPaymentMode.addActionListener(e -> {
			String mode = (String) cbPaymentMode.getSelectedItem();
			boolean showCard = mode.equals("Debit") || mode.equals("Credit");
			lblCardNumber.setVisible(showCard);
			tfCardNumber.setVisible(showCard);
			if (!showCard) {
				tfCardNumber.setText("");
			}
		});

		/**
		 * Event Listener: Generate Bill button clicked. Validates inputs, calculates
		 * total, formats the bill text, displays the bill, and adjusts textarea height
		 * dynamically.
		 */
		btnGenerate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Clear previous error messages
				lblErrorMessage.setText("");

				// Get and trim input values
				String profFeeStr = tfProfFee.getText().trim();
				String amountStr = tfAmount.getText().trim();
				String discountStr = tfDiscount.getText().trim();
				String paymentMode = (String) cbPaymentMode.getSelectedItem();
				String cardNum = tfCardNumber.getText().trim();

				// Basic validation for required fields
				if (profFeeStr.isEmpty() || amountStr.isEmpty() || discountStr.isEmpty() || paymentMode.isEmpty()) {
					lblErrorMessage.setText("Please fill in all required fields.");
					return;
				}

				// If payment mode requires card, validate card number length
				if ((paymentMode.equals("Debit") || paymentMode.equals("Credit")) && cardNum.length() != 16) {
					lblErrorMessage.setText("Please enter a valid 16-digit card number.");
					return;
				}

				double profFee, amount, discount;
				try {
					profFee = Double.parseDouble(profFeeStr);
					amount = Double.parseDouble(amountStr);
					discount = Double.parseDouble(discountStr);
				} catch (NumberFormatException ex) {
					lblErrorMessage.setText("Please enter valid numeric values for fees and discount.");
					return;
				}

				// Calculate total charges
				double total = profFee + amount - discount;

				// Get current date and time formatted as MM/dd/yyyy HH:mm:ss in Asia/Manila
				// timezone
				ZonedDateTime now = ZonedDateTime.now(ZoneId.of("Asia/Manila"));
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");
				String date = now.format(formatter);

				// Mask card number except last 4 digits for privacy
				String cardDisplay = "";
				if (!cardNum.isEmpty()) {
					cardDisplay = "**** **** **** " + cardNum.substring(12);
				}

				// Build the bill string with clear section titles and formatting
				StringBuilder bill = new StringBuilder();
				bill.append("*************** OsMak eConsult ***************\n\n");

				bill.append("=== Patient Information ===\n");
				bill.append("-------------------\n");
				bill.append("Name: ").append(patientName).append("\n");
				bill.append("Patient ID: ").append(patientID).append("\n");
				bill.append("Address: ").append(patientAddress).append("\n");
				bill.append("Phone Number: ").append(patientPhone).append("\n");
				bill.append("Date: ").append(date).append("\n\n");

				bill.append("=== Hospital Charges ===\n");
				bill.append("Professional Fee: ₱").append(String.format("%.2f", profFee)).append("\n");
				bill.append("Lab Test: ").append(cbLabTest.getSelectedItem()).append("\n");
				bill.append("Test Amount: ₱").append(String.format("%.2f", amount)).append("\n");
				bill.append("Discount: ₱").append(String.format("%.2f", discount)).append("\n\n");

				bill.append("=== Payment Details ===\n");
				bill.append("Payment Mode: ").append(paymentMode).append("\n");
				if (!cardDisplay.isEmpty()) {
					bill.append("Card Number: ").append(cardDisplay).append("\n");
				}
				bill.append("----------------------------------------------\n");
				bill.append("Total Amount: ₱").append(String.format("%.2f", total)).append("\n");
				bill.append("----------------------------------------------\n");
				bill.append("Thank you for choosing OsMak eConsult!\n");

				// Set the generated bill text into the text area
				textArea.setText(bill.toString());

				// Dynamically adjust the text area height to fit content or enable wrapping if
				// too long
				adjustTextAreaHeight();
			}
		});

		/**
		 * Event Listener: Clear button clicked. Resets all input fields, hides card
		 * number input, clears the bill and error messages.
		 */
		btnClear.addActionListener(e -> {
			tfProfFee.setText("");
			tfAmount.setText("");
			tfDiscount.setText("");
			tfCardNumber.setText("");
			cbLabTest.setSelectedIndex(0);
			cbPaymentMode.setSelectedIndex(0);
			lblCardNumber.setVisible(false);
			tfCardNumber.setVisible(false);
			textArea.setText("");
			lblErrorMessage.setText("");
			adjustTextAreaHeight();
		});
	}

	/**
	 * Adjusts the JTextArea height dynamically based on its content. - Calculates
	 * the number of lines. - Sets the height accordingly. - If the content is too
	 * tall, enables line wrap and limits max height.
	 */
	private void adjustTextAreaHeight() {
		int lineCount = textArea.getLineCount(); // number of lines in the text area
		int lineHeight = textArea.getFontMetrics(textArea.getFont()).getHeight(); // height of one line
		int padding = 10; // extra padding for better spacing

		// Calculate new height based on lines and padding
		int newHeight = lineHeight * lineCount + padding;
		int maxHeight = 400; // maximum height before enabling wrap

		if (newHeight > maxHeight) {
			// Content too long: limit height and enable wrapping
			newHeight = maxHeight;
			textArea.setLineWrap(true);
			textArea.setWrapStyleWord(true);
		} else {
			// Content fits: disable wrapping for better formatting
			textArea.setLineWrap(false);
		}

		// Resize text area height to new calculated height
		textArea.setBounds(textArea.getX(), textArea.getY(), textArea.getWidth(), newHeight);

		// Refresh UI to apply changes
		contentPane.repaint();
	}
}