package LoginPackage;

import java.awt.*;
import javax.swing.*;

public class LoginDesign extends JFrame {

	private static final long serialVersionUID = 1L;
	private JTextField textField;
	private JPasswordField passwordField;
	private JLabel lblMessage; // Label for error messages

	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {
			try {
				LoginDesign frame = new LoginDesign();
				frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

	public LoginDesign() {
		setTitle("OsMak eConsult Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setSize(1000, 600);
		setLocationRelativeTo(null); // Center on screen

		getContentPane().setLayout(new BorderLayout());

		// Left Gradient Panel (assuming GradientPanel exists)
		GradientPanel leftPanel = new GradientPanel();
		leftPanel.setPreferredSize(new Dimension(400, 0));
		leftPanel.setLayout(new GridBagLayout()); // Center label
		getContentPane().add(leftPanel, BorderLayout.WEST);

		JLabel lblOsmakEconsult = new JLabel("OsMak. eConsult");
		lblOsmakEconsult.setForeground(Color.WHITE);
		lblOsmakEconsult.setFont(new Font("Dialog", Font.BOLD, 25));
		leftPanel.add(lblOsmakEconsult);

		// Right Panel
		JPanel rightPanel = new JPanel();
		rightPanel.setLayout(null);
		getContentPane().add(rightPanel, BorderLayout.CENTER);

		JLabel lblWelcome = new JLabel("Welcome, Admin");
		lblWelcome.setForeground(new Color(124, 124, 124));
		lblWelcome.setFont(new Font("Dialog", Font.BOLD, 25));
		lblWelcome.setBounds(203, 103, 217, 30);
		rightPanel.add(lblWelcome);

		textField = new JTextField();
		textField.setBounds(164, 171, 274, 30);
		rightPanel.add(textField);
		textField.setColumns(10);

		JLabel lblEmailAddress = new JLabel("Email address");
		lblEmailAddress.setForeground(new Color(124, 124, 124));
		lblEmailAddress.setFont(new Font("Dialog", Font.BOLD, 14));
		lblEmailAddress.setBounds(164, 143, 203, 30);
		rightPanel.add(lblEmailAddress);

		JLabel lblPassword = new JLabel("Password");
		lblPassword.setForeground(new Color(124, 124, 124));
		lblPassword.setFont(new Font("Dialog", Font.BOLD, 14));
		lblPassword.setBounds(164, 221, 203, 30);
		rightPanel.add(lblPassword);

		passwordField = new JPasswordField();
		passwordField.setBounds(164, 245, 274, 30);
		rightPanel.add(passwordField);

		JCheckBox chckbxShowPassword = new JCheckBox("Show password");
		chckbxShowPassword.setBounds(164, 289, 121, 21);
		rightPanel.add(chckbxShowPassword);

		chckbxShowPassword.addActionListener(e -> {
			if (chckbxShowPassword.isSelected()) {
				passwordField.setEchoChar((char) 0); // Show password
			} else {
				passwordField.setEchoChar('•'); // Hide password
			}
		});

		JButton btnLogin = new JButton("Login");
		btnLogin.setBackground(new Color(3, 140, 218));
		btnLogin.setForeground(Color.WHITE);
		btnLogin.setBounds(160, 345, 85, 30);
		rightPanel.add(btnLogin);

		lblMessage = new JLabel("");
		lblMessage.setForeground(Color.RED);
		lblMessage.setBounds(164, 390, 300, 25);
		rightPanel.add(lblMessage);

		btnLogin.addActionListener(e -> login());

		// Also allow pressing Enter in password or email field to login
		passwordField.addActionListener(e -> login());
		textField.addActionListener(e -> login());
	}

	private void login() {
		String email = textField.getText().trim();
		String password = new String(passwordField.getPassword());

		if (email.equals("admin") && password.equals("pass")) {
			lblMessage.setForeground(new Color(0, 128, 0)); // Green
			lblMessage.setText("Login Successful! Welcome, Admin.");
		} else {
			lblMessage.setForeground(Color.RED);
			lblMessage.setText("Invalid email or password");
		}
	}
}
